((window.gitter = {}).chat = {}).options = {
  room: 'loraserver/lora-gateway-bridge'
};
