package gateway

import (
	log "github.com/Sirupsen/logrus"
)

func init() {
	log.SetLevel(log.ErrorLevel)
}
